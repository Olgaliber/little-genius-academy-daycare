<?php

get_post( $page->ID );

?><section>
</section>